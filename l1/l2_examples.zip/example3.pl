% I den här databasen kan alla 4 personerna vara spindeln i nätet.
person(p1).
person(p2).
person(p3).
person(p4).
knows(p1,p2).
knows(p2,p3).
knows(p3,p4).
knows(p4,p1).
