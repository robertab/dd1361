% I den här databasen kan ingen vara spindeln i nätet, eftersom p3
% inte känner någon -- om p3 vore spindeln i nätet kan ingen vara
% konspiratör och således känner varken p1 eller p2 någon konspiratör,
% och om p3 inte vore spindeln i nätet kan p3 inte heller vara
% konspiratör och kommer heller inte känna någon konspiratör.

person(p1).
person(p2).
person(p3).
knows(p1,p2).
